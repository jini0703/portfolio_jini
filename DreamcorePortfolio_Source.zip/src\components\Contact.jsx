import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

export default function Contact() {
  const containerRef = useRef(null);
  const contentRef = useRef(null);
  const certRef = useRef(null);

  useEffect(() => {
    gsap.fromTo(contentRef.current,
      { opacity: 0, scale: 0.9, y: 50 },
      {
        opacity: 1, scale: 1, y: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: contentRef.current,
          start: 'top 95%',
        }
      }
    );

    gsap.fromTo(certRef.current,
      { opacity: 0, y: 50 },
      {
        opacity: 1, y: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: certRef.current,
          start: 'top 95%',
        }
      }
    );
  }, []);

  const certs = [
    { title: "Data Analytics Job Simulation – Deloitte", link: "https://drive.google.com/file/d/1efHEH9KRo4bxq3R2rVBqMl1BjYjZH8Do/preview" },
    { title: "AWS Technical Essentials", link: "https://drive.google.com/file/d/1uaGQJrquk27VjzRtdsBkVxDoghC-5WQ7/preview" },
    { title: "AWS Cloud Practitioner Essentials", link: "https://drive.google.com/file/d/19kaKdouYiPSLp00ljn8716_HW7BxbO0A/preview" },
    { title: "AWS Certified Cloud Practitioner", link: "https://drive.google.com/file/d/1JckMJHxKjGdKJ22bVjIUUTEKYjwTVgbR/preview" },
    { title: "Generative AI Foundations", link: "https://drive.google.com/file/d/1CeTIbuE4dhv18fqQAgqTf3Jh4UjjYKXF/preview" },
    { title: "OCI AI Foundations Associate", link: "https://drive.google.com/file/d/1apE-tNuP4-TQnEtbBJY8J4MLftd-p4OJ/preview" },
    { title: "OCI Gen AI Professional", link: "https://drive.google.com/file/d/1G82QlCQBemn1brxuSzc42fiCGT7evboF/preview" }
  ];

  return (
    <section 
      ref={containerRef}
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '10vh 5vw',
        gap: '4rem'
      }}
    >
      <div 
        ref={certRef}
        className="glass"
        style={{
          padding: '4rem',
          borderRadius: '30px',
          maxWidth: '1000px',
          width: '100%',
        }}
      >
        <h2 style={{
          fontFamily: 'var(--font-serif)',
          fontSize: '3rem',
          color: 'var(--color-primary)',
          marginBottom: '2rem',
          textAlign: 'center'
        }}>Certifications</h2>
        
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '1rem'
        }}>
          {certs.map((cert, i) => (
            <a 
              key={i} 
              href={cert.link} 
              target="_blank" 
              rel="noreferrer"
              style={{
                background: 'rgba(255,255,255,0.05)',
                padding: '1.5rem',
                borderRadius: '15px',
                border: '1px solid var(--glass-border)',
                textDecoration: 'none',
                color: 'var(--color-text-main)',
                fontFamily: 'var(--font-sans)',
                fontSize: '1rem',
                transition: 'all 0.3s ease',
                display: 'flex',
                alignItems: 'center'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'var(--glass-bg)';
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 5px 15px var(--glass-shadow)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              📄 {cert.title}
            </a>
          ))}
        </div>
      </div>

      <div 
        ref={contentRef}
        className="glass-panel"
        style={{
          padding: '6rem 4rem',
          borderRadius: '40px',
          textAlign: 'center',
          maxWidth: '800px',
          width: '100%',
        }}
      >
        <h2 
          style={{
            fontFamily: 'var(--font-serif)',
            fontSize: '4.5rem',
            marginBottom: '1.5rem',
            color: 'var(--color-primary)',
            textShadow: '0 0 20px var(--text-glow)'
          }}
        >
          Let's Connect
        </h2>
        
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '1rem',
          fontFamily: 'var(--font-sans)',
          fontSize: '1.2rem',
          color: 'var(--color-text-main)',
          marginBottom: '4rem',
          opacity: 0.9
        }}>
          <p>📍 Faridabad, India</p>
          <p>📞 +91 9958474205</p>
          <p>✉️ anjinipandey71@gmail.com</p>
          <p>🎓 anjini.pandey2024@vitstudent.ac.in</p>
        </div>

        <a 
          href="mailto:anjinipandey71@gmail.com"
          style={{
            display: 'inline-block',
            padding: '1.2rem 3rem',
            background: 'var(--glass-bg)',
            border: '1px solid var(--glass-border)',
            borderRadius: '50px',
            color: 'var(--color-text-main)',
            textDecoration: 'none',
            fontFamily: 'var(--font-sans)',
            fontSize: '1.1rem',
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            transition: 'all 0.3s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255, 105, 180, 0.3)';
            e.currentTarget.style.boxShadow = '0 0 30px var(--glass-shadow)';
            e.currentTarget.style.transform = 'translateY(-3px)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'var(--glass-bg)';
            e.currentTarget.style.boxShadow = 'none';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          Send Message
        </a>
      </div>
    </section>
  );
}
