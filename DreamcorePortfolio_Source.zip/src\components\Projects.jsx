import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

export default function Projects() {
  const containerRef = useRef(null);
  const titleRef = useRef(null);
  const projectsRef = useRef([]);

  useEffect(() => {
    gsap.fromTo(titleRef.current,
      { opacity: 0, x: -50 },
      {
        opacity: 1, x: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: titleRef.current,
          start: 'top 95%',
        }
      }
    );

    projectsRef.current.forEach((el, index) => {
      gsap.fromTo(el,
        { opacity: 0, y: 100, scale: 0.95 },
        {
          opacity: 1, y: 0, scale: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: el,
            start: 'top 95%',
          }
        }
      );
    });
  }, []);

  const projects = [
    { 
      title: "CURO", 
      subtitle: "AI-Powered Career Assistant",
      desc: "Engineered a full-stack AI-driven career companion featuring comprehensive resume parsing, interview preparation workflows, and personalized job recommendation engines.",
      tech: "React, TypeScript, Supabase, TanStack",
      link: "https://curo-five.vercel.app/"
    },
    { 
      title: "Pixel Canvas", 
      subtitle: "Interactive Web Application",
      desc: "A digital drawing tool allowing users to create custom grid sizes and select brush colors to design pixel artwork effortlessly.",
      tech: "HTML, CSS, JavaScript",
      link: "https://jini0703.github.io/all-tasks-project/ass2/index.html"
    },
    { 
      title: "Roommate Finder", 
      subtitle: "Full-Stack Platform",
      desc: "A platform designed to help college students find highly compatible roommates based on detailed lifestyle preferences and habits.",
      tech: "HTML, CSS, JavaScript",
      link: "https://jini0703.github.io/all-tasks-project/group%20project/index.html"
    },
    { 
      title: "Web Dev Archive", 
      subtitle: "Creative UI Experiments",
      desc: "A complete collection of all my front-end development assignments, mini-projects, and creative UI experiments.",
      tech: "HTML, CSS, JavaScript",
      link: "https://jini0703.github.io/all-tasks-project/"
    }
  ];

  return (
    <section 
      ref={containerRef}
      style={{
        minHeight: '100vh',
        padding: '10vh 10vw',
        perspective: '1000px'
      }}
    >
      <h2 
        ref={titleRef}
        style={{
          fontFamily: 'var(--font-serif)',
          fontSize: '4rem',
          marginBottom: '5rem',
          color: 'var(--color-primary)',
          textShadow: '0 0 20px rgba(255,105,180,0.3)'
        }}
      >
        Projects
      </h2>

      <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '8rem'
      }}>
        {projects.map((proj, i) => (
          <div 
            key={i}
            ref={el => projectsRef.current[i] = el}
            className="glass-panel"
            style={{
              display: 'flex',
              flexDirection: i % 2 === 0 ? 'row' : 'row-reverse',
              alignItems: 'center',
              padding: '4rem',
              borderRadius: '30px',
              gap: '5rem',
              transformStyle: 'preserve-3d',
              transition: 'transform 0.5s ease',
              boxShadow: '0 10px 40px var(--glass-shadow)',
              flexWrap: 'wrap'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-10px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            <div style={{ flex: '1 1 300px' }}>
              <div style={{ 
                width: '100%', 
                paddingBottom: '60%', 
                background: 'rgba(255,255,255,0.05)',
                borderRadius: '20px',
                position: 'relative',
                overflow: 'hidden',
                border: '1px solid var(--glass-border)'
              }}>
                <div style={{
                  position: 'absolute',
                  inset: 0,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--color-text-main)',
                  opacity: 0.5,
                  fontFamily: 'var(--font-serif)',
                  fontSize: '2.5rem',
                  fontStyle: 'italic'
                }}>
                  {proj.title[0]}
                </div>
              </div>
            </div>
            
            <div style={{ flex: '2 1 300px' }}>
              <h3 style={{
                fontFamily: 'var(--font-sans)',
                fontSize: '2.5rem',
                color: 'var(--color-text-main)',
                marginBottom: '0.5rem',
                textShadow: '0 0 10px var(--text-glow)'
              }}>
                {proj.title}
              </h3>
              <h4 style={{
                fontFamily: 'var(--font-serif)',
                fontSize: '1.2rem',
                color: 'var(--color-primary)',
                marginBottom: '1.5rem',
                fontStyle: 'italic'
              }}>
                {proj.subtitle}
              </h4>
              <p style={{
                fontFamily: 'var(--font-sans)',
                fontSize: '1.1rem',
                color: 'var(--color-text-muted)',
                lineHeight: 1.6,
                marginBottom: '1rem'
              }}>
                {proj.desc}
              </p>
              <p style={{
                fontFamily: 'var(--font-sans)',
                fontSize: '0.9rem',
                color: 'var(--color-accent)',
                letterSpacing: '0.05em',
                marginBottom: '2rem'
              }}>
                {proj.tech}
              </p>
              
              <a 
                href={proj.link}
                target="_blank"
                rel="noreferrer"
                style={{
                  display: 'inline-block',
                  padding: '1rem 2.5rem',
                  background: 'transparent',
                  border: '1px solid var(--glass-border)',
                  borderRadius: '50px',
                  color: 'var(--color-text-main)',
                  textDecoration: 'none',
                  fontFamily: 'var(--font-sans)',
                  fontSize: '1rem',
                  letterSpacing: '0.1em',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(255,105,180,0.2)';
                  e.currentTarget.style.boxShadow = '0 0 20px var(--glass-shadow)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                VIEW PROJECT
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
