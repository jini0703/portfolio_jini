import React, { useEffect } from 'react';
import Lenis from 'lenis';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import DreamWorldCanvas from './components/DreamWorldCanvas';
import Hero from './components/Hero';
import About from './components/About';
import Projects from './components/Projects';
import Contact from './components/Contact';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const [introComplete, setIntroComplete] = React.useState(false);
  
  // Auto-detect system preference on first load
  const [theme, setTheme] = React.useState(() => {
    if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  });

  useEffect(() => {
    // Force the browser to start at the very top (the cave) on refresh
    if ('scrollRestoration' in window.history) {
      window.history.scrollRestoration = 'manual';
    }
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    // Initialize premium buttery smooth scroll but snappier
    const lenis = new Lenis({
      duration: 0.8, // Reduced from 1.5 for a more responsive scroll
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      direction: 'vertical',
      gestureDirection: 'vertical',
      smooth: true,
      mouseMultiplier: 1,
      smoothTouch: false,
      touchMultiplier: 2,
      infinite: false,
    });

    window.lenis = lenis; // Expose for scrollTo

    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0, 0);

    return () => {
      lenis.destroy();
      window.lenis = null;
      gsap.ticker.remove(lenis.raf);
    };
  }, []);

  useEffect(() => {
    if (introComplete) return;

    const st = ScrollTrigger.create({
      trigger: '#intro-zone',
      start: 'top top',
      end: 'bottom top',
      onLeave: () => {
        setIntroComplete(true);
        // Instantly snap scroll to top using Lenis to prevent layout/scroll fighting
        if (window.lenis) {
          window.lenis.scrollTo(0, { immediate: true });
        } else {
          window.scrollTo(0, 0);
        }
      }
    });

    return () => st.kill();
  }, [introComplete]);

  return (
    <>
      {/* Theme Toggle Button */}
      <button 
        onClick={() => setTheme(t => t === 'light' ? 'dark' : 'light')}
        style={{
          position: 'fixed',
          top: '2rem',
          right: '2rem',
          zIndex: 9999,
          background: 'var(--glass-bg)',
          border: '1px solid var(--glass-border)',
          borderRadius: '50%',
          width: '50px',
          height: '50px',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '1.5rem',
          color: 'var(--color-text-main)',
          boxShadow: '0 4px 15px var(--glass-shadow)',
          backdropFilter: 'blur(10px)',
          transition: 'all 0.3s ease'
        }}
      >
        {theme === 'light' ? '🌙' : '🌸'}
      </button>

      {/* Fixed Animated 3D Background */}
      <div id="canvas-container" style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: 0, pointerEvents: 'none' }}>
        <DreamWorldCanvas introComplete={introComplete} theme={theme} />
      </div>

      {/* Main Scroll Container */}
      <div id="scroll-container" style={{ position: 'relative', zIndex: 1, width: '100%' }}>
        
        {/* The Intro Scroll Zone - User scrolls this to trigger the 3D Zoom */}
        {!introComplete && (
          <div id="intro-zone" style={{ height: '300vh', width: '100%' }}>
            <div style={{
              position: 'absolute',
              top: '50vh',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              color: '#fff',
              fontFamily: 'var(--font-sans)',
              letterSpacing: '0.2em',
              opacity: 0.8,
              animation: 'bounce 2s infinite ease-in-out'
            }}>
              Scroll to Enter
            </div>
          </div>
        )}

        {/* Normal Website Content Starts Here */}
        <div style={{ position: 'relative', background: 'transparent' }}>
          <Hero />
          <About />
          <Projects />
          <Contact />
        </div>
      </div>
    </>
  );
}

export default App;
