import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export default function Hero() {
  const containerRef = useRef(null);

  useEffect(() => {
    gsap.fromTo(containerRef.current.children, 
      { y: 100, opacity: 0, filter: 'blur(10px)' },
      {
        y: 0,
        opacity: 1,
        filter: 'blur(0px)',
        stagger: 0.2,
        duration: 2,
        ease: 'power3.out',
        // This animation triggers when this component mounts, which is effectively when the user reaches this section
      }
    );
  }, []);

  return (
    <section 
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '10vh 5vw',
        position: 'relative'
      }}
    >
      <div 
        ref={containerRef}
        className="glass-panel"
        style={{
          padding: '6rem 4rem',
          borderRadius: '30px',
          textAlign: 'center',
          maxWidth: '800px',
          width: '100%'
        }}
      >
        <h1 
          style={{
            fontFamily: 'var(--font-serif)',
            fontSize: '5rem',
            margin: '0 0 1rem 0',
            color: 'var(--color-text-main)',
            textShadow: '0 0 20px rgba(255,105,180,0.5)'
          }}
        >
          Anjini Pandey
        </h1>
        <h2 
          style={{
            fontFamily: 'var(--font-serif)',
            fontSize: '2rem',
            color: 'var(--color-primary)',
            margin: '0 0 2rem 0',
            fontStyle: 'italic'
          }}
        >
          CSE Student • Web Developer • Cloud & AI
        </h2>
        <p 
          style={{
            fontFamily: 'var(--font-sans)',
            fontSize: '1.2rem',
            lineHeight: 1.6,
            color: 'var(--color-text-muted)',
            letterSpacing: '0.05em',
            marginBottom: '3rem'
          }}
        >
          Passionate about web development, cloud computing, and exploring generative AI. I enjoy building modern projects and constantly learning new technologies.
        </p>

        <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'center', flexWrap: 'wrap' }}>
          {[
            { name: 'Resume', url: 'https://drive.google.com/file/d/1g_Cj9RXy5367DA_ZQK4mxRMSBeBP5l69/view?usp=sharing' },
            { name: 'LinkedIn', url: 'https://www.linkedin.com/in/anjini-pandey-76a479319' },
            { name: 'GitHub', url: 'https://github.com/jini0703' }
          ].map((link, i) => (
            <a 
              key={i}
              href={link.url}
              target="_blank"
              rel="noreferrer"
              style={{
                padding: '0.8rem 2rem',
                borderRadius: '50px',
                border: '1px solid var(--glass-border)',
                background: 'var(--glass-bg)',
                color: 'var(--color-text-main)',
                textDecoration: 'none',
                fontFamily: 'var(--font-sans)',
                fontSize: '1rem',
                letterSpacing: '0.1em',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(255, 105, 180, 0.2)';
                e.currentTarget.style.boxShadow = '0 0 20px var(--glass-shadow)';
                e.currentTarget.style.transform = 'translateY(-3px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'var(--glass-bg)';
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              {link.name}
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
